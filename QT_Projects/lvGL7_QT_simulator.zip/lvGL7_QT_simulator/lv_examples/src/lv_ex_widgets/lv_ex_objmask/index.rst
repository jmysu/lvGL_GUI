C
^

Several object masks
""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_objmask/lv_ex_objmask_1
  :language: c
      
      
Text mask
"""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_objmask/lv_ex_objmask_2
  :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
